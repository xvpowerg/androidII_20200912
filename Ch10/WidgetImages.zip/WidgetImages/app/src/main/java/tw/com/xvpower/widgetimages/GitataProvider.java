package tw.com.xvpower.widgetimages;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.util.Log;
import android.widget.RemoteViews;

import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class GitataProvider  extends AppWidgetProvider {
    private Bitmap[] bitmaps = new Bitmap[24];
    private static String ACTION_STOP_IMAGES="stop_images";
    private AppWidgetManager manager;
    private RemoteViews remoteViews;
    private ComponentName thisWidget;
    private static ScheduledExecutorService executorService;
    private Handler handler = new Handler();
    private MyRun myRun;
    private int index = 0;
    private static boolean runAnimation = true;

    private void updateDataTime(){
        remoteViews.setImageViewBitmap(R.id.gitgitImag,bitmaps[index]);
        index = ++index % bitmaps.length;
        manager.updateAppWidget(thisWidget,remoteViews);
    }

    private class MyRun implements Runnable{
        @Override
        public void run() {
            Log.d("Howard","MyRun...");
            if (runAnimation){
                handler.post(()->updateDataTime());
            }

        }
    }
    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        Log.d("Howard","onUpdate:");
        thisWidget = new ComponentName(context,GitataProvider.class);
        manager = appWidgetManager;

        executorService = Executors.newSingleThreadScheduledExecutor();
        myRun = new MyRun();
        remoteViews = new RemoteViews(context.getPackageName(),
                R.layout.widget_layout);

        Intent intentButton = new Intent(context,GitataProvider.class);
        intentButton.setAction(ACTION_STOP_IMAGES);
        final PendingIntent pendingIntent = PendingIntent.
                getBroadcast(context,0,intentButton,
                        PendingIntent.FLAG_UPDATE_CURRENT);
        remoteViews.setOnClickPendingIntent(R.id.gitgitImag,pendingIntent);

        for (int i =0; i < bitmaps.length;i++){
            try(InputStream is =
                        context.getAssets().open(String.format("gitgit%d.png",i+1))){
                Bitmap bitmap = BitmapFactory.decodeStream(is);
                bitmaps[i] = bitmap;
            }catch (IOException ex){
                Log.e("Howard","ex:"+ex);
                break;
            }
        }
        Log.d("Howard","onUpdate:"+bitmaps[0]);
        executorService.scheduleAtFixedRate(myRun,0,
                100, TimeUnit.MILLISECONDS);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);

        if (intent.getAction().equals(ACTION_STOP_IMAGES)){
            runAnimation = !runAnimation;
        }
    }

    @Override
    public void onDisabled(Context context) {
        executorService.shutdown();

    }
}
