package tw.com.xvpower.firebasephotoproject;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.InputStream;

public class UploadActivity extends AppCompatActivity {

    private Button uploadBtn;
    private StorageReference mStorageRef;
    private FirebaseAuth firebaseAuth;
    private String uid = "";
    private void uploadAction(View view){
       InputStream input =  getResources().openRawResource(R.raw.image1);
       UploadTask uploadTask =  mStorageRef.child("test1").child(uid).
                child("test.png").putStream(input);
        uploadTask.addOnCompleteListener(task->{
                    if (task.isSuccessful()){
                        Toast.makeText(this,"上傳成功",Toast.LENGTH_SHORT).show();
                        Log.d("Howard","上傳成功:");
                    }else{
                        String error = task.getException().getMessage();
                        Log.e("Howard","error:"+error);
                        Toast.makeText(this,"上傳失敗",Toast.LENGTH_SHORT).show();
                    }
        });
    }
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.upload);
        uploadBtn = findViewById(R.id.upload_btn);
        uploadBtn.setOnClickListener(this::uploadAction);
        mStorageRef = FirebaseStorage.getInstance().getReference();
        firebaseAuth = FirebaseAuth.getInstance();
        uid = firebaseAuth.getUid();

    }
}
