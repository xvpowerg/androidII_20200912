package tw.com.xvpower.firebasephotoproject;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import java.util.concurrent.TimeUnit;

public class RegisterActivity extends AppCompatActivity {
    private EditText emailText;
    private EditText passText1;
    private EditText passText2;
    private Button loginBtn;
    private  Button regBtn;
    private FirebaseAuth mAuth;

    private void init(){
        emailText = findViewById(R.id.accountTxt);
        passText1 =findViewById(R.id.passText1);
        passText2 =findViewById(R.id.passText2);
        loginBtn = findViewById(R.id.login_btn);
        regBtn = findViewById(R.id.reg_btn);
        mAuth = FirebaseAuth.getInstance();
    }

    private void onRegisterCompleteListener(Task<AuthResult> task){
            if (task.isSuccessful()){
                Intent  mainIntent =
                        new Intent(this,MainActivity.class);
                startActivity(mainIntent);
                Toast.makeText(this, R.string.app_register_successful,
                        Toast.LENGTH_SHORT).show();
                finish();
            }else{
                String msg = getString(R.string.app_register_fail)+
                        ":"+task.getException().toString();
                Toast.makeText(this, msg,
                        Toast.LENGTH_SHORT).show();
            }
    }


    private  void register(View v){
        //檢查email 或密碼是否為空白 如有錯顯示帳號密碼不可空白
        //檢查 密碼1與密碼2是否相等 如果有錯顯示密碼驗證錯誤
        //以上都正確就註冊
        String email = emailText.getText().toString();
        String pass1 = passText1.getText().toString();
        String pass2 = passText2.getText().toString();

        if (TextUtils.isEmpty(email) ||
        TextUtils.isEmpty(pass1) || TextUtils.isEmpty(pass2)){
            Toast.makeText(this,
                    R.string.account_pass_not_empty,
                    Toast.LENGTH_SHORT).show();
        }else if(!pass1.equals(pass2)){
            Toast.makeText(this,
                    R.string.app_confirm_pss_fail,
                    Toast.LENGTH_SHORT).show();
        }else{
            mAuth.createUserWithEmailAndPassword(email,pass1).
                    addOnCompleteListener(this::onRegisterCompleteListener);
        }

    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);
        init();
        loginBtn.setOnClickListener(v->{
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
            finish();
        });

        regBtn.setOnClickListener(this::register);
    }

}
