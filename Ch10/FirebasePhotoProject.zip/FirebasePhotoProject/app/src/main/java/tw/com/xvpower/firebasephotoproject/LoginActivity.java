package tw.com.xvpower.firebasephotoproject;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity  extends AppCompatActivity {
    private EditText loginEmailText;
    private EditText loginPassText;
    private Button loginBtn;
    private  Button regBtn;
    private FirebaseAuth mAuth;


    private void init(){
        mAuth = FirebaseAuth.getInstance();
        loginEmailText = findViewById(R.id.accountTxt);
        loginPassText = findViewById(R.id.passText1);
        loginBtn = findViewById(R.id.login_btn);
        regBtn = findViewById(R.id.reg_btn);
    }

    private void toMainPage(){
        Intent mainIntent = new Intent(this,MainActivity.class);
        startActivity(mainIntent);
        finish();
    }

    private void completeListener(Task<AuthResult> task){
            if (task.isSuccessful()){
                toMainPage();
            }else{
                Log.w("Howard",getString(R.string.app_login_fail_msg)+
                        ":"+task.getException().toString());
                Toast.makeText(this,R.string.app_login_fail_msg,
                        Toast.LENGTH_LONG).show();

            }

    }

    private void loginAction(View view){
            String email = loginEmailText.getText().toString();
            String pass = loginPassText.getText().toString();
            if (TextUtils.isEmpty(email) || TextUtils.isEmpty(pass)){
                Toast.makeText(this,
                        R.string.account_pass_not_empty,
                        Toast.LENGTH_SHORT).show();
            }else{
                mAuth.signInWithEmailAndPassword(email,pass).
                        addOnCompleteListener(this::completeListener);
            }
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        init();
       loginBtn.setOnClickListener(this::loginAction);
       regBtn.setOnClickListener(v->{
            Intent toRegIntent = new Intent(this,
                    RegisterActivity.class);
            startActivity(toRegIntent);
            finish();
        });
    }

}
