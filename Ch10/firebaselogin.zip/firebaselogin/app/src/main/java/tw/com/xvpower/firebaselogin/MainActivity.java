package tw.com.xvpower.firebaselogin;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private EditText accountEText;
    private EditText passETxt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mAuth = FirebaseAuth.getInstance();
        accountEText = findViewById(R.id.accountTxt);
        passETxt = findViewById(R.id.password);
        Button registerBtn = findViewById(R.id.registerBtn);
        Button loginBtn =  findViewById(R.id.loginBtn);

        registerBtn.setOnClickListener(v->{
            String email =   accountEText.getText().toString();
            String pass = passETxt.getText().toString();
            mAuth.createUserWithEmailAndPassword(email,pass).
                    addOnCompleteListener((Task<AuthResult> task)->{
                          if (task.isSuccessful()){
                              Log.d("Howard","Success!");
                          }else{
                              Log.w("Howard","Fail!");
                          }
                    });
        });

        loginBtn.setOnClickListener(v->{
            String email =   accountEText.getText().toString();
            String pass = passETxt.getText().toString();
            mAuth.signInWithEmailAndPassword(email,pass).addOnCompleteListener(task->{
                    if (task.isSuccessful()){
                        Log.d("Howard","Login Successful!!");
                       FirebaseUser fuser =
                               FirebaseAuth.getInstance().getCurrentUser();
                       if (fuser != null){

                           String name = fuser.getEmail();
                           Log.d("Howard","Name:"+name);
                       }
                    }else{
                        Log.e("Howard","Login Faill"+task.getException());
                    }

            });
        });
    }
}