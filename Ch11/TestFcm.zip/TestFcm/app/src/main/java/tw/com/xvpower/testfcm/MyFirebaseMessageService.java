package tw.com.xvpower.testfcm;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public class MyFirebaseMessageService extends FirebaseMessagingService {
    private String ChANNEL_ID = "FcmMsg";

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void createChannel(){
    NotificationManager notificationManager =
        (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
       //如果已經有這個ChANNEL 就不建立新的ChANNEL
        if (notificationManager.getNotificationChannel(ChANNEL_ID) != null){
            return;
        }
        //Channel名稱
        final  String name = "ForFCM";
        //Channel描述
        final  String desname = "FCM";
        //Channel 的重要性
       final  int  importance = NotificationManager.IMPORTANCE_DEFAULT;
        NotificationChannel channel = new NotificationChannel(ChANNEL_ID,
                name,importance);
        channel.setDescription(desname);
        notificationManager.createNotificationChannel(channel);
    }
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onMessageReceived(@NonNull RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);
        Log.d("Howard","From:"+remoteMessage.getFrom());
        if (remoteMessage.getNotification()!= null){
            Log.d("Howard","From:"+remoteMessage.getNotification().getBody());
            final  int id = 1;
            createChannel();
            NotificationCompat.Builder builder =
                    new NotificationCompat.Builder(this,ChANNEL_ID);
            builder.setSmallIcon(R.drawable.ic_baseline_message_24);
            builder.setPriority(NotificationCompat.PRIORITY_DEFAULT);
             String title = remoteMessage.getNotification().getTitle();
             String body = remoteMessage.getNotification().getBody();
            builder.setContentTitle(title);
            builder.setContentText(body);
            NotificationManagerCompat.from(this).notify(id,builder.build());
        }


    }
}
