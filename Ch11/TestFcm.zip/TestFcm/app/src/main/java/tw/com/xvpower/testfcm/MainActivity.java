package tw.com.xvpower.testfcm;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.messaging.FirebaseMessaging;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        FirebaseMessaging.getInstance().
                getToken().addOnCompleteListener(task->{
            String token =
                    task.getResult();
            Log.d("Howard","token:"+token);

        });

//        FirebaseInstanceId.getInstance().getInstanceId().
//                addOnCompleteListener(task->{
//                        String token =
//                                task.getResult().getToken();
//                    Log.d("Howard","token:"+token);
//                });
    }
}