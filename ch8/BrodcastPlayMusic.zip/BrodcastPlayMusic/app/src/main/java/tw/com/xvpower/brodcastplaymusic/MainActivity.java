package tw.com.xvpower.brodcastplaymusic;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private MediaPlayer mediaPlayer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button playBtn = findViewById(R.id.playBtn);
        Button pauseBtn = findViewById(R.id.pauseBtn);
        Button stopBtn = findViewById(R.id.stopBtn);

        playBtn.setOnClickListener(v->{
            if (mediaPlayer == null){
                mediaPlayer = MediaPlayer.create(this,R.raw.test);
            }
            mediaPlayer.start();
        });
        pauseBtn.setOnClickListener(v->{
            mediaPlayer.pause();
        });
        stopBtn.setOnClickListener(v->{
            mediaPlayer.stop();
            mediaPlayer = null;
        });
    }
}