package tw.com.xvpower.use_provider;

import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class MyCursorAdapter  extends RecyclerView.Adapter<MyCursorAdapter.MyViewHolder>{
    private  Cursor cursor;
    public MyCursorAdapter(Cursor cursor){
            this.cursor = cursor;
    }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view =  LayoutInflater.from(parent.getContext()).
                inflate(R.layout.rc_layout,parent,false);
        MyViewHolder myViewHolder = new MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
            if (cursor.moveToPosition(position)){
                 String id = String.valueOf(cursor.getInt(0));
                 holder.idText.setText(id);
                 holder.nameText.setText(cursor.getString(1));
                 holder.priceText.setText(cursor.getString(2));
            }
    }

    @Override
    public int getItemCount() {
        return cursor.getCount();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {
            TextView  idText;
            TextView nameText;
            TextView priceText;
         public MyViewHolder(@NonNull View itemView) {
             super(itemView);
             idText = itemView.findViewById(R.id.idText);
             nameText = itemView.findViewById(R.id.nameText);
             priceText =  itemView.findViewById(R.id.priceText);
         }
     }
}
