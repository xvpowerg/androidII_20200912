package tw.com.xvpower.use_provider;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {
    private static final Uri myUri = Uri.parse("content://tw.com.xvpower.testloader.MyProivder");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ContentResolver cr =  getContentResolver();
        /*
        @NonNull Uri uri, @Nullable String[] projection, @Nullable String selection,
             @Nullable String[] selectionArgs, @Nullable String sortOrder
         */
       Cursor cursor =  cr.query(myUri,new String[]{"_id","title","price"},
                null,null,null);
        Log.d("Howard",cursor+"");
        MyCursorAdapter mca = new MyCursorAdapter(cursor);
        RecyclerView rcList = findViewById(R.id.rcView);
        rcList.setLayoutManager(new LinearLayoutManager(this));
        rcList.setAdapter(mca);
    }
}