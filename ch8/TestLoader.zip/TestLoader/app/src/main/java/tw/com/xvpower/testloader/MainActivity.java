package tw.com.xvpower.testloader;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;

import androidx.loader.app.LoaderManager;
import androidx.loader.content.Loader;

import tw.com.xvpower.testloader.loader.MyCursorLoader;

public class MainActivity extends AppCompatActivity
        implements  LoaderManager.LoaderCallbacks<Cursor>{

        private LoaderManager loaderManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        loaderManager = LoaderManager.getInstance(this);
        loaderManager.initLoader(1,null,this);
    }

    @NonNull
    @Override
    public Loader<Cursor> onCreateLoader(int id, @Nullable Bundle args) {
        Log.d("Howard","onCreateLoader Thread Name:"+Thread.currentThread().getName());
        MyCursorLoader mycloader = new MyCursorLoader(this);
        return mycloader;
    }

    @Override
    public void onLoadFinished(@NonNull Loader<Cursor> loader, Cursor data) {
        Log.d("Howard",
                "onLoadFinished Thread Name:"+
                        Thread.currentThread().getName());
        Log.d("Howard",
                "onLoadFinished Cursor size:"+
                        data.getCount());
    }

    @Override
    public void onLoaderReset(@NonNull Loader<Cursor> loader) {

    }
}