package tw.com.xvpower.testservice1project;

import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;
import java.time.LocalTime;
import java.util.Date;

import androidx.annotation.Nullable;

public class MyService extends Service {
    private Handler handler = new Handler();
    boolean canRun = true;
    int count = 0;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        Log.d("Howard","onBind!!!");

        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d("Howard","onCreate...");
    }
private void myrun(){
    Runnable run = new Runnable() {
        int runCount = 0;
        @Override
        public void run() {
            Log.d("Howard",new Date().toString());
            Log.d("Howard",Thread.currentThread().getName());
            if (++runCount < count){
                //執行
                canRun = false;
                handler.postDelayed(this,1000);
            }else{
                //執行完畢了
                canRun = true;
            }
        }
    };
    if (canRun){
        handler.post(run);
    }

}
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d("Howard","onStartCommand");
        //Service.START_STICKY Service 被Android 系統移除後
        // 會自動啟動Service 但是 Intent 為 null
        //Service.START_REDELIVER_INTENT Service 被Android 系統移除後
        // 會自動啟動Service 但是 Intent 不為 null
        //  Service.START_NOT_STICKY Service 被Android 系統移除後
        //              不會自動啟動Service
        String countStr = intent.getStringExtra("count");
        count =   Integer.parseInt(countStr);
        myrun();
        return Service.START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        count = -1;
        Log.d("Howard","onDestroy");
    }
}
