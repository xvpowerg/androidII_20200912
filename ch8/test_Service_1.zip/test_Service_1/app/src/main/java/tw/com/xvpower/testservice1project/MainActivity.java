package tw.com.xvpower.testservice1project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button startBtn = findViewById(R.id.startBtn);
        Button stopBtn =  findViewById(R.id.stopBtn);
        EditText countEdit =  findViewById(R.id.countEdit);
        startBtn.setOnClickListener(v->{
//Activity 跟　Service是分開的
            Intent startIntent = new Intent(this,MyService.class);
            String count = countEdit.getText().toString();
            startIntent.putExtra("count",count);
            startService(startIntent);
        });

        stopBtn.setOnClickListener(v->{
            Intent stopIntent =
                    new Intent(this,MyService.class);
            stopService(stopIntent);
        });

    }
}