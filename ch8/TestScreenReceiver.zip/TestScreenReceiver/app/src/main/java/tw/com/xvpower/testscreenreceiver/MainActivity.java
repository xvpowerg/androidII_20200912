package tw.com.xvpower.testscreenreceiver;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.widget.CheckBox;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ScreenReceiver screenReceiver = new ScreenReceiver();
        CheckBox rgBox =  findViewById(R.id.registerBox);
        rgBox.setOnCheckedChangeListener((c,isChecked)->{
            if (isChecked){
                IntentFilter filter = new IntentFilter();
                filter.addAction(Intent.ACTION_SCREEN_ON);
                filter.addAction(Intent.ACTION_SCREEN_OFF);
                registerReceiver(screenReceiver,filter);
            }else if(screenReceiver != null){
                unregisterReceiver(screenReceiver);
            }

        });

    }
}