package tw.com.xvpower.testscreenreceiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class ScreenReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d("Howard","onReceive:!!!");

        switch (intent.getAction()){
            case Intent.ACTION_SCREEN_ON:
                Log.d("Howard","SCREEN_ON");
                break;
            case Intent.ACTION_SCREEN_OFF:
                Log.d("Howard","SCREEN_OFF");
                break;

        }

    }
}
