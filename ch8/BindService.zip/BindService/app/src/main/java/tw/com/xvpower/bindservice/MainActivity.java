package tw.com.xvpower.bindservice;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
        private MyBindService.MyBinder myBinder;
        private EditText countEdit;
        private TextView msgText;
    ServiceConnection sc = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            myBinder = (MyBindService.MyBinder)service;
            myBinder.msgTextView = msgText;
            Log.d("Howard","onServiceConnected!!:"+service);
        }
        //不正常移除Service時呼叫
        @Override
        public void onServiceDisconnected(ComponentName name) {
            Log.d("Howard","onServiceDisconnected!!");
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button bindBtn=  findViewById(R.id.bindBtn);
        Button setBtn =   findViewById(R.id.setBtn);
        Button invokeBtn =  findViewById(R.id.invokeBtn);
        Button stopBtn = findViewById(R.id.stopBtn);
        stopBtn.setEnabled(false);
         countEdit =  findViewById(R.id.countEdit);
         msgText =  findViewById(R.id.msgText);

        bindBtn.setOnClickListener(v->{
            Intent bindIntent =
                    new Intent(this,MyBindService.class);
           bindService(bindIntent,sc, Context.BIND_AUTO_CREATE);
            stopBtn.setEnabled(true);
        });

        setBtn.setOnClickListener(v->{
            int count = Integer.parseInt(countEdit.getText().toString());
            myBinder.countStart =count;
            myBinder.showText();
        });

        invokeBtn.setOnClickListener(v->{
            myBinder.startCountdown();
        });
        stopBtn.setOnClickListener(v->{
          unbindService(sc);
            stopBtn.setEnabled(false);
        });

    }
}