package tw.com.xvpower.bindservice;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.Nullable;

import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

public class MyBindService  extends Service {
    private MyBinder myBinder = new MyBinder();

    private class RunCountdown implements  Runnable{
        @Override
        public void run() {
            for (int i = myBinder.countStart; !myBinder.stop && i >= 0;i--){
                myBinder.msgTextView.setText(i+"");
                try{
                    TimeUnit.SECONDS.sleep(1);
                }catch(Exception ex){}

            }
        }
    }


    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        Log.d("Howard","onBind");
        return myBinder;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d("Howard","onCreate");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d("Howard","onStartCommand");
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d("Howard","onDestroy");
    }

    @Override
    public boolean onUnbind(Intent intent) {
        Log.d("Howard","onUnbind");
        myBinder.stopCountDown();
        return super.onUnbind(intent);
    }



//像Activity 與 Service溝通的管道
    public final class MyBinder extends Binder{
        public int countStart;
        private boolean stop = false;
        public TextView msgTextView;
        public  void showText(){
            msgTextView.setText(countStart+"");
        }
       public void startCountdown(){
           RunCountdown run = new RunCountdown();
           Thread th1 = new Thread(run);
           th1.start();
       }

       public void stopCountDown(){
            Log.d("Howard","stopCountDown!!");
            stop = true;
       }
        private  MyBinder(){

        }

    }
}
