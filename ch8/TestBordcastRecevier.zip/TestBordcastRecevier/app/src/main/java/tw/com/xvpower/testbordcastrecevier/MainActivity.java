package tw.com.xvpower.testbordcastrecevier;

import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private BroadcastReceiver myReve = new MyReceiver();
    private TextView msgView;
    private BroadcastReceiver myReve2 = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            msgView.setText("myReve2!!");
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button sendBtn =  findViewById(R.id.sendMsg);
        msgView = findViewById(R.id.msgView);
        sendBtn.setOnClickListener(v->{
            Intent i = new Intent("test.br.myrece");
            sendBroadcast(i);

            Intent i2 = new Intent("test.br.myrece2");
            sendBroadcast(i2);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        //動態註冊接收器
        IntentFilter filter = new IntentFilter();
        filter.addAction("test.br.myrece");
        registerReceiver(myReve,filter);

        IntentFilter filter2 = new IntentFilter();
        filter2.addAction("test.br.myrece2");
        registerReceiver(myReve2,filter2);
    }
}