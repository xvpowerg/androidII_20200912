package tw.com.xvpower.testloader.tools;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import tw.com.xvpower.testloader.R;

public class DatabaseTools {

    public static SQLiteDatabase openDatabase(String dbFilePath , Context context){
        String dbFileName = "coffee_5000.db";
        //資料庫在Android的位置
        File dbFile = new File(dbFilePath,dbFileName);
        if (!dbFile.exists() ){
            try(InputStream str =
                        context.getResources().openRawResource(R.raw.coffee_5000);
                FileOutputStream fos = new FileOutputStream(dbFile)){
                byte[ ] buffer = new byte[1024];
                int index = -1;
                while((index = str.read(buffer)) != -1){
                    fos.write(buffer,0,index);
                }
            }catch (IOException ex){
                Log.e("DatabaseTools","copy coffee_5000 error:"+ex);
            }
        }
     SQLiteDatabase db =
             SQLiteDatabase.openOrCreateDatabase(dbFile,null);
        return db;
    }
}
