package tw.com.xvpower.testloader.loader;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.loader.content.CursorLoader;

import tw.com.xvpower.testloader.tools.DatabaseTools;

public class MyCursorLoader extends CursorLoader {
    public MyCursorLoader(@NonNull Context context) {
        super(context);
    }

    @Nullable
    @Override
    protected Cursor onLoadInBackground() {
        Log.d("Howard","onLoadInBackground Thread Name:"+Thread.currentThread().getName());
        String dbPath =  getContext().getFilesDir().getAbsolutePath();
        SQLiteDatabase sqldb =
                DatabaseTools.openDatabase(dbPath,getContext());
       Cursor cursor =
               sqldb.rawQuery("SELECT _id,title,price FROM coffee_list",
                       null);
        return cursor;
    }
}
