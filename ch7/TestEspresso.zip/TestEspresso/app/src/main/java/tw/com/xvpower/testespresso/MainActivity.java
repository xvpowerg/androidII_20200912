package tw.com.xvpower.testespresso;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button calcuBtn =   findViewById(R.id.calcuBtn);
        TextView ansText =  findViewById(R.id.ansText);
        calcuBtn.setOnClickListener(v -> {
            EditText n1Et = findViewById(R.id.number1);
            EditText n2Et = findViewById(R.id.number2);

            int n1 = Integer.parseInt(n1Et.getText().toString());
            int n2 = Integer.parseInt(n2Et.getText().toString());
            int ans = n1 + n2;
            ansText.setText(ans+"");
        });

         Spinner spinner = findViewById(R.id.citySpinner);
        ArrayAdapter<String> adapter = new ArrayAdapter(this,
                android.R.layout.simple_list_item_1,
                android.R.id.text1,
                getResources().getStringArray(R.array.city));
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent,
                                       View view, int position,
                                       long id) {
               String city =  parent.getAdapter().getItem(position).toString();
                ansText.setText(city);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }
}