package tw.com.xvpower.testespresso;

import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.hamcrest.Matcher;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onData;
import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;

@RunWith(AndroidJUnit4.class)
public class UiTest {
    @Rule
    public ActivityScenarioRule<MainActivity> activityRule =
            new ActivityScenarioRule(MainActivity.class);
@Test
    public void testCalculate(){
            int n1 = 10;
            int n2 = 20;
            //onView 在畫面上
        //withId id是number1
        //perform 我的動作是
        //typeText 輸入文字
       onView(withId(R.id.number1)).
                    perform(typeText(n1+""));
       onView(withId(R.id.number2)).
                    perform(typeText(n2+""));
       //按下click
       onView(withId(R.id.calcuBtn)).perform(click());
       //設定條件 ansText 內容是否符合此條件
        Matcher m1 = allOf(withText(n1+n2+""));
        //檢查ansText是否符合條件
       onView(withId(R.id.ansText)).check(matches(m1));
    }

    @Test
    public void testSpinner(){
        String testCity = "台中";
        onView(withId(R.id.citySpinner)).perform(click());
        //針對一般Adapter
        onData(allOf(instanceOf(String.class),is(testCity))).perform(click());
        Matcher m2 = allOf(withText(testCity));
        onView(withId(R.id.ansText)).check(matches(m2));
    }

}
