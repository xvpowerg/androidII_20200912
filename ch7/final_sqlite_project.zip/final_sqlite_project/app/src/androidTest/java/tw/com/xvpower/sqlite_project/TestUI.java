package tw.com.xvpower.sqlite_project;

import androidx.test.ext.junit.rules.ActivityScenarioRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.hamcrest.Matcher;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;

import java.util.Random;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.clearText;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.longClick;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.contrib.RecyclerViewActions.actionOnItem;
import static androidx.test.espresso.matcher.ViewMatchers.hasDescendant;
import static androidx.test.espresso.matcher.ViewMatchers.hasSibling;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.not;
import static tw.com.xvpower.sqlite_project.matcher.Utils.hasItem;

@RunWith(AndroidJUnit4.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class TestUI {
    static String testName,testScore,updateTestName,updateTestScore;
    static Matcher m1,m2;

    @BeforeClass
    public static void init(){
        Random random = new Random();
        testName = "TestV1"+random.nextInt(500000);
        testScore = random.nextInt(5000000)+".0";
        updateTestName = "UpTestV2"+random.nextInt(500000);
        updateTestScore = random.nextInt(500000)+".0";

        m1 = allOf(withText(testName),hasSibling(withText(testScore)));
        m2 = allOf(withText(updateTestName),hasSibling(withText(updateTestScore)));
        
    }

    @Rule
   public ActivityScenarioRule<MainActivity> activityRule =
            new ActivityScenarioRule<MainActivity>(MainActivity.class);
//英文字母大小作為執行順序 由小到大執行
    @Test
    public void aTestInsert(){
        String name = testName;
        String score = testScore;
        onView(withId(R.id.fab)).perform(click());
        onView(withId(R.id.nameEdit)).
                perform(typeText(name));
        onView(withId(R.id.scoreEdit)).
                perform(typeText(score));
    // android.R.id.button1 for positive,
    // android.R.id.button2 for negative,
    // and android.R.id.button3 for neutral.
        onView(withId(android.R.id.button1)).perform(click());
        onView(withId(R.id.rcView)).check(matches(
                hasItem(hasDescendant(m1))));
    }

    @Test
    public void bTestUpdate(){
        String name = testName;
        String score = testScore;

        String nameUp = updateTestName;
        String scoreUp = updateTestScore;

        //rcview專用 actionOnItem
        onView(withId(R.id.rcView)).perform(
                actionOnItem(hasDescendant(m1),longClick()));
        onView(withText("更新")).perform(click());
        //彈跳視窗的內容與我要搜尋的是否一致
        onView(withId(R.id.nameEdit)).check(matches(withText(name)));
        onView(withId(R.id.scoreEdit)).check(matches(withText(score)));
        //清空
        onView(withId(R.id.nameEdit)).perform(clearText());
        onView(withId(R.id.scoreEdit)).perform(clearText());
        //填入新數值
        onView(withId(R.id.nameEdit)).perform(typeText(nameUp));
        onView(withId(R.id.scoreEdit)).perform(typeText(scoreUp));
        //按下確定
        onView(withId(android.R.id.button1)).perform(click());
        //檢查是否在Rcview上有更新
        onView(withId(R.id.rcView)).check(
                matches(hasItem(hasDescendant(m2))));
    }


    @Test
    public void cTestDelete(){
        onView(withId(R.id.rcView)).
                perform(actionOnItem(hasDescendant(m2),
                        longClick()));
        onView(withText("刪除")).perform(click());
        onView(withId(R.id.rcView)).
                check(matches(not(hasItem(hasDescendant(m2)))));
    }
}
