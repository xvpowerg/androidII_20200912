package tw.com.xvpower.sqlite_project.sqlite;

public interface SqliteTable {
    String getTableName();
    DBHelper getDBHelper();
}
