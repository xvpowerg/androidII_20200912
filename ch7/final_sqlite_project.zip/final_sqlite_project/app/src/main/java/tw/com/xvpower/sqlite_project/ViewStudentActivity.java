package tw.com.xvpower.sqlite_project;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import tw.com.xvpower.sqlite_project.bean.Student;

public class ViewStudentActivity extends AppCompatActivity {

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_student_layout);
        Intent intent = getIntent();
        Student student =
                intent.getParcelableExtra("student");
        TextView id = findViewById(R.id.viewId);
        TextView name = findViewById(R.id.viewName);
        TextView score = findViewById(R.id.viewScore);
        id.setText(student.getId()+"");
        name.setText(student.getName());
        score.setText(student.getScore()+"");
    }


}
