package tw.com.xvpower.testrecyclerview;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RcAdapter extends RecyclerView.Adapter<RcAdapter.MyViewHolder> {
    private List<TestData> listData = null;

    public RcAdapter(List<TestData> listData){
        this.listData = listData;
    }

    //產生ViewHolder
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       View view =  LayoutInflater.from(parent.getContext()).
               inflate(R.layout.list_layout,
                parent,
                false);
        MyViewHolder myViewHolder = new MyViewHolder(view);
        return myViewHolder;
    }
    //綁定ViewHolder數據
    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        TestData tdata =  listData.get(position);
        holder.t1.setText(tdata.getText1());
        holder.t2.setText(tdata.getText2());
        holder.t3.setText(tdata.getText3());
        holder.imageView.setImageResource(tdata.getImage());
    }

    @Override
    public int getItemCount() {
        return listData.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder{
            TextView t1;
            TextView t2;
            TextView t3;
            ImageView imageView;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            t1 = itemView.findViewById(R.id.textView1);
            t2 = itemView.findViewById(R.id.textView2);
            t3 = itemView.findViewById(R.id.textView3);
            imageView = itemView.findViewById(R.id.imageView);
        }
    }
}
