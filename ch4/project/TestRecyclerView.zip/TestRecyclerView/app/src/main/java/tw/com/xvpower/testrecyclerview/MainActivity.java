package tw.com.xvpower.testrecyclerview;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private int[] images = {R.drawable.image1,R.drawable.image2,
                            R.drawable.image3,R.drawable.image4};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RecyclerView rcv =  findViewById(R.id.rcView);
        List<TestData> listData = new ArrayList<>();
        //一定要加
        rcv.setLayoutManager(new LinearLayoutManager(this));
        for (int i =1;i<=500000;i++){
            TestData tdata = new TestData(i+"",
                    i+"test2",i+"test3",
                    images[i % images.length]);
            listData.add(tdata);
        }
        RcAdapter rca = new RcAdapter(listData);
        rcv.setAdapter(rca);

        rcv.addOnItemTouchListener(new RecyclerView.OnItemTouchListener() {
            @Override
            public boolean onInterceptTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {
                return true;
            }

            @Override
            public void onTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {
                Log.d("Howard","RecyclerView...onTouchEvent");
            }

            @Override
            public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

            }
        });
    }
}