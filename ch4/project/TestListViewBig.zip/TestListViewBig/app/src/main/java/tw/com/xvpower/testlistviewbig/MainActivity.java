package tw.com.xvpower.testlistviewbig;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private int[] images={
            R.drawable.image1,
            R.drawable.image2,
            R.drawable.image3,
            R.drawable.image4
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       ListView listView =  findViewById(R.id.listView);
       List<TestData> testDataList = new ArrayList<>();

       for(int i = 1;i<=500000;i++){
            TestData td = new TestData(i+"",i+"Text2",
                    i+"Test3",images[i % images.length]);
           testDataList.add(td);
       }

       MyBaseAdapter baseAdapter = new MyBaseAdapter(testDataList);
       listView.setAdapter(baseAdapter);

    }
}