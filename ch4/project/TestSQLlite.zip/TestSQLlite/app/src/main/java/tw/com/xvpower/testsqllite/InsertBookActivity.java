package tw.com.xvpower.testsqllite;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class InsertBookActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert_book);
    }
}