package tw.com.xvpower.sqlite_project;

import android.content.Context;
import android.util.Log;

import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.List;

import tw.com.xvpower.sqlite_project.bean.Student;
import tw.com.xvpower.sqlite_project.sqlite.DBHelper;

import static org.junit.Assert.*;

/**
 * Instrumented test, which will execute on an Android device.
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
@RunWith(AndroidJUnit4.class)
public class ExampleInstrumentedTest {
    private  static Context appContext;
    private  static  DBHelper dbHelper;
    //整個測試期間只執行一次
    @BeforeClass
    public static void init(){
        System.out.println("BeforeClass!");
         appContext =
                InstrumentationRegistry.getInstrumentation().getTargetContext();
         dbHelper = new DBHelper(appContext);
    }
    //每個Test 執行一次
    @Before
    public void init2(){
        System.out.println("Before!");
    }

    @Test
    public void testStudentInsert(){

        Student st1 = new Student(-1,"Lucy",98.6f,"");
        int id =  dbHelper.getStudentDao().insert(st1);
        System.out.println("id:"+id);
        assertTrue("INSERT Error!",id > 0);
    }

    @Test
    public void testQueryStudentById(){
        int id = 3;
        Student st =  dbHelper.getStudentDao().queryStudentById(id);
        assertTrue("QueryStudentById Error!",st != null);
    }

    @Test
    public void testQueryAllStudent(){
        List<Student> list = dbHelper.getStudentDao().queryAllStudent();
        Log.d("Howard","List:"+list.size());
        assertTrue("QueryAllStudent Error!",list.size() > 0);
    }

    @Test
    public void testUpdateStudent(){
        Student st = new Student(7,"Gigi",75,"");
        int count = dbHelper.getStudentDao().update(st);
        assertTrue("Update Error",count > 0);
    }

    @Test
    public void testDeleteStudent(){
        Student st = new Student(6,"",1,"");
        int count = dbHelper.getStudentDao().delete(st);
      assertTrue("Delete error",count > 0);
    }

}