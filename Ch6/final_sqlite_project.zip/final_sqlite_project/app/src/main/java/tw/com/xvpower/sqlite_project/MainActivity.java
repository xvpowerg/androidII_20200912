package tw.com.xvpower.sqlite_project;

import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import java.util.List;

import tw.com.xvpower.sqlite_project.adapter.StudentAdapter;
import tw.com.xvpower.sqlite_project.bean.Student;
import tw.com.xvpower.sqlite_project.sqlite.DBHelper;
import tw.com.xvpower.sqlite_project.view.StudentAlertEdit;
import tw.com.xvpower.sqlite_project.view.MenuAction;

public class MainActivity extends AppCompatActivity {
    private DBHelper dbHelper;
    private  RecyclerView rcView;
    private StudentAdapter studentAdapter;
    private StudentAlertEdit studentAlertEdit;
    private MenuAction menuAction;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        dbHelper = new DBHelper(this);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        FloatingActionButton fab = findViewById(R.id.fab);
        studentAlertEdit = new StudentAlertEdit(this);

        studentAlertEdit.setInsertAction((st)->{
            int id = dbHelper.getStudentDao().insert(st);
            if (id > 0){
                st.setId(id);
                studentAdapter.addStudent(st);
                Toast.makeText(this,"新增成功",Toast.LENGTH_SHORT).show();
            }
        });
        studentAlertEdit.setUpdateAction(st->{
           int count =  dbHelper.getStudentDao().update(st);
            if (count > 0){
                studentAdapter.updateStudent(st);
                Toast.makeText(this,"更新成功",Toast.LENGTH_SHORT).show();
            }

        });
         fab.setOnClickListener(v->{
             studentAlertEdit.showInsert();
         });
        rcView = findViewById(R.id.rcView);
        DividerItemDecoration itemDecoration =
                new DividerItemDecoration(this,DividerItemDecoration.VERTICAL);
        //幫RecyclerView加上線
        rcView.addItemDecoration(itemDecoration);
        menuAction = new MenuAction(this);
    }


    @Override
    protected void onStart() {
        super.onStart();
        List<Student> stList =
                dbHelper.getStudentDao().queryAllStudent();

        studentAdapter = new StudentAdapter(stList,
                menuAction::onRcViewLongClick);

         rcView.setLayoutManager(new LinearLayoutManager(this));
         rcView.setAdapter(studentAdapter);

    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.menu_view:
                Log.d("Howard","View");
                menuAction.viewStudent();
                break;
            case R.id.menu_update:
                Log.d("Howard","Update");
                menuAction.
                        updateStudent(studentAlertEdit::showUpdate);

                break;
            case R.id.menu_delete:
                Log.d("Howard","Delete");
                menuAction.deleteStudent(st->{
                    int count = dbHelper.getStudentDao().delete(st);
                    if (count > 0 ){
                       studentAdapter.deleteStudent(st);
                        Toast.makeText(this,"刪除成功",Toast.LENGTH_SHORT).show();
                    }
                });
                break;

        }
        return super.onContextItemSelected(item);
    }
}