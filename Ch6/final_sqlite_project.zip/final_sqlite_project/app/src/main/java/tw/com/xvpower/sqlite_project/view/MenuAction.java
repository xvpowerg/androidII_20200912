package tw.com.xvpower.sqlite_project.view;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

import java.util.function.Consumer;

import tw.com.xvpower.sqlite_project.ViewStudentActivity;
import tw.com.xvpower.sqlite_project.bean.Student;

public class MenuAction {
    private Context context;
    public MenuAction(Context context){
            this.context = context;
    }
    private Student currentStudent=null;
    public  void onRcViewLongClick(Student st){
//        Toast.makeText(context,"LongClick Id:"+st.getId(),
//                Toast.LENGTH_SHORT).show();
        currentStudent = st;
    }
    public void viewStudent(){
        Intent  toIntent = new Intent(context,
                ViewStudentActivity.class);
        toIntent.putExtra("student",currentStudent);
        context.startActivity(toIntent);

    }
    public void updateStudent(Consumer<Student> callback){
        callback.accept(currentStudent);
    }
    public void deleteStudent(Consumer<Student> callback){
        callback.accept(currentStudent);
    }

}
