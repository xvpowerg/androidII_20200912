package tw.com.xvpower.ch2_3_ordersystem.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

import tw.com.xvpower.ch2_3_ordersystem.R;
import tw.com.xvpower.ch2_3_ordersystem.bean.Order;

public class OrderAdapter  extends BaseAdapter {

    private List<Order> orderList;
    public OrderAdapter(List<Order> orderList){
        this.orderList = orderList;
    }
    @Override
    public int getCount() {
        return orderList.size();
    }

    @Override
    public Order getItem(int position) {
        return orderList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return getItem(position).getOrderId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
       View view = LayoutInflater.from(parent.getContext()).
                inflate(R.layout.list_view_layout,parent,false);
       TextView orderIdText =  view.findViewById(R.id.listOrderId);
       TextView orderTitleText =  view.findViewById(R.id.lisOredrTitle);
       Order order =   getItem(position);
        orderIdText.setText(order.getOrderId()+"");
        orderTitleText.setText(order.getTitle());
        return view;
    }
}
