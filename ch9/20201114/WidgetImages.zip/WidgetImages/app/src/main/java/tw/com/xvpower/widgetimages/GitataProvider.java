package tw.com.xvpower.widgetimages;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.widget.RemoteViews;

import java.io.IOException;
import java.io.InputStream;

public class GitataProvider  extends AppWidgetProvider {
    private Bitmap[] bitmaps = new Bitmap[24];
    private AppWidgetManager manager;
    private RemoteViews remoteViews;
    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        Log.d("Howard","onUpdate:");
        manager = appWidgetManager;
        remoteViews = new RemoteViews(context.getPackageName(),
                R.layout.widget_layout);
        for (int i =0; i < bitmaps.length;i++){
            try(InputStream is =
                        context.getAssets().open(String.format("gitgit%d.png",i+1))){
                Bitmap bitmap = BitmapFactory.decodeStream(is);
                bitmaps[i] = bitmap;
            }catch (IOException ex){
                Log.e("Howard","ex:"+ex);
                break;
            }
        }
        Log.d("Howard","onUpdate:"+bitmaps[0]);

    }
}
