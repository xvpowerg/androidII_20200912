package tw.com.xvpower.brodcastopenactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private  OpenActivityReceiver oaReceiver;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn =  findViewById(R.id.openPage2);
        btn.setOnClickListener(v->{
            Intent actionIntent =
                    new Intent(getString(R.string.page2_action));
            sendBroadcast(actionIntent);
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(getString(R.string.page2_action));
        if (oaReceiver == null){
            oaReceiver = new OpenActivityReceiver();
        }
        registerReceiver(oaReceiver,intentFilter);
    }

    @Override
    protected void onPause() {
        super.onPause();
        //unregisterReceiver(oaReceiver);
        //oaReceiver = null;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(oaReceiver);
        oaReceiver = null;
    }
}