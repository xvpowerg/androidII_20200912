package tw.com.xvpower.test_widget1;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.util.Log;
import android.widget.RemoteViews;

import java.util.Calendar;
import java.util.concurrent.TimeUnit;


public class TestAppWidget extends AppWidgetProvider {
    private Handler handler = new Handler() ;
    private AppWidgetManager manager;
    private RemoteViews remoteViews ;
    private ComponentName thisWidget;
    private static boolean stopTime = false;

    private void resetTime(){
        while(!stopTime){
            handler.post(this::updateTime);//更新時間
            try {
                TimeUnit.SECONDS.sleep(1);
            } catch (InterruptedException e) { }
        }
    }

    private void updateTime(){
        Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR);
        int minute = calendar.get(Calendar.MINUTE);
        int second =  calendar.get(Calendar.SECOND);
        String time = String.format("%02d:%02d:%02d",
                hour,minute,second);
        remoteViews.setTextViewText(R.id.widget_text,time);
       // Log.d("Howard","time:"+time+"stopTime:"+stopTime+" this:"+this.hashCode());
        manager.updateAppWidget(thisWidget,remoteViews);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        Log.d("Howard","onReceive.... this:");
    }

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        super.onUpdate(context, appWidgetManager, appWidgetIds);
        thisWidget = new ComponentName(context,TestAppWidget.class);
        manager = appWidgetManager;
        remoteViews = new RemoteViews(context.getPackageName(),
                R.layout.widget_layout);
        Thread thread = new Thread(this::resetTime);
        thread.start();
    }

    @Override
    public void onDeleted(Context context, int[] appWidgetIds) {
        super.onDeleted(context, appWidgetIds);
        Log.d("Howard","onDeleted....");

    }

    @Override
    public void onEnabled(Context context) {
        super.onEnabled(context);
        Log.d("Howard","onEnabled....");
        stopTime = false;

    }

    @Override
    public void onDisabled(Context context) {
        super.onDisabled(context);
        Log.d("Howard","onDisabled....");
        stopTime = true;
        Log.d("Howard","onDisabled....:"+stopTime+" this:"+this.hashCode());
    }
}
