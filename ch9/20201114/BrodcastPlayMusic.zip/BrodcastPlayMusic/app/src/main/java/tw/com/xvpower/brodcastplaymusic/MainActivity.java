package tw.com.xvpower.brodcastplaymusic;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.IntentFilter;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private MediaPlayer mediaPlayer;
    private Mp3Receiver mp3Receiver;

    private  void sendAction(String action){
        Intent actionIntent = new Intent(action);
        sendBroadcast(actionIntent);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button playBtn = findViewById(R.id.playBtn);
        Button pauseBtn = findViewById(R.id.pauseBtn);
        Button stopBtn = findViewById(R.id.stopBtn);

        playBtn.setOnClickListener(v->{
//            if (mediaPlayer == null){
//                mediaPlayer = MediaPlayer.create(this,R.raw.test);
//            }
//            mediaPlayer.start();
            sendAction(getString(R.string.music_play_action));
        });
        pauseBtn.setOnClickListener(v->{
           // mediaPlayer.pause();
            sendAction(getString(R.string.music_pause_action));
        });
        stopBtn.setOnClickListener(v->{
//            mediaPlayer.stop();
//            mediaPlayer = null;
            sendAction(getString(R.string.music_stop_action));
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        IntentFilter mp3Filter = new IntentFilter();
        mp3Filter.addAction(getString(R.string.music_pause_action));
        mp3Filter.addAction(getString(R.string.music_stop_action));
        mp3Filter.addAction(getString(R.string.music_play_action));

        if (mp3Receiver == null){
            mp3Receiver = new Mp3Receiver();
        }
        registerReceiver(mp3Receiver,mp3Filter);
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(mp3Receiver);
        mp3Receiver = null;
    }
}