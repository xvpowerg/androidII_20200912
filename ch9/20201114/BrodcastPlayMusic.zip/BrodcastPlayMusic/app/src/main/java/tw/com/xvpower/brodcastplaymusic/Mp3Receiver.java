package tw.com.xvpower.brodcastplaymusic;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.util.Log;

import java.util.HashMap;
import java.util.Map;

public class Mp3Receiver  extends BroadcastReceiver {

    private MediaPlayer mediaPlayer;

    private void play(Context context){
        if (mediaPlayer == null){
            mediaPlayer = MediaPlayer.create(context,R.raw.test);
        }
        mediaPlayer.start();
    }
    private void pause(){
        mediaPlayer.pause();
    }
    private void stop(){
        mediaPlayer.stop();
        mediaPlayer = null;
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        Log.d("Howard","action:"+action);
        Map <String,Runnable> actionMap = InitActionMap.init(context,
                ()->play(context),
                this::stop,
                this::pause);

      Runnable runaction =   actionMap.getOrDefault(action,()->
        { throw  new IllegalArgumentException("無效的動作!");});
        runaction.run();

    }
}
