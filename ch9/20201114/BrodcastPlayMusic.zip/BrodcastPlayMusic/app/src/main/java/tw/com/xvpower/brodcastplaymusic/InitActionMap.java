package tw.com.xvpower.brodcastplaymusic;

import android.content.Context;

import java.util.HashMap;
import java.util.Map;

public class InitActionMap {

    public static Map init(Context context,Runnable ...run){
         Map<String,Runnable> actionMap = new HashMap<>();
        final String PLAY = context.getString(R.string.music_play_action);
        final String Stop = context.getString(R.string.music_stop_action);
        final String PAUSE = context.getString(R.string.music_pause_action);
        actionMap.put(PLAY,run[0]);
        actionMap.put(Stop,run[1]);
        actionMap.put(PAUSE,run[2]);
        return actionMap;
    }

}
